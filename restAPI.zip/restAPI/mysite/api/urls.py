from django.urls import path
from . import views

urlpatterns = [
    path('index/',views.index),
    path('add_post/',views.add_post, name='add_post'),
    path('',views.show_posts, name='show_posts'),
]
