from django.shortcuts import render,redirect
from .serializers import PostSerializer
# Create your views here.
from rest_framework import viewsets
from .models import Posts
from django.contrib import messages
from .forms import PostForm


def index(request):
    return render(request,'index.html')


def add_post(request):
    form =PostForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        form.save()
        messages.success(request, 'Form save successfully.')
        return redirect('add_post')
        print('Form save successfully')


    context ={
        'form':form
    }

    return render(request,'add-post.html',context)

def show_posts(request):
    p =Posts.objects.all()

    context={
        'p':p
    }

    return render(request,'show-posts.html',context)


class PostView(viewsets.ModelViewSet):
    queryset =Posts.objects.all()
    serializer_class = PostSerializer









