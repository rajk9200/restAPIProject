from django.db import models

# Create your models here.
from datetime import date
class Posts(models.Model):
    title =models.CharField(max_length=100)
    desc =models.TextField()
    image =models.ImageField(default="abcd.png" , upload_to='posts')
    author =models.CharField(max_length=100)
    created= models.DateField(default=date.today)

    def __str__(self):
        return self.title








